﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HalsteadsMethodTool
{
    public partial class Form1 : Form
    {
        double length = 0, volume = 0, level = 0, estimated_length = 0, effort = 0, vocabulary = 0, difficulty = 0, time = 0, bugs = 0;

        private void rjButton1_Click(object sender, EventArgs e)
        {
            double n1 = 0, n2 = 0, N1 = 0, N2 = 0;
            try
            {
                n1 = double.Parse(txt_distinct_operators.Texts);
                n2 = double.Parse(txt_distinct_operands.Texts);
                N1 = double.Parse(txt_total_operators.Texts);
                N2 = double.Parse(txt_total_operands.Texts);
            }
            catch (Exception ex)
            {
                MessageBox.Show("All inputs must be filled out with int >= 0");
            }
            if (n1 <= 0 || n2 <= 0 || N1 <= 0 || N2 <= 0)
            {
                MessageBox.Show("All inputs must be filled out with int >= 0");
            }
            calculate(n1, N1, n2, N2);
            txt_length.Texts = Math.Round(length, 2) + "";
            txt_vocabulary.Texts = Math.Round(vocabulary, 2) + "";
            txt_volume.Texts = Math.Round(volume, 2) + "";
            txt_estimated_length.Texts = Math.Round(estimated_length, 2) + "";
            txt_level.Texts = Math.Round(level, 2) + "";
            txt_time.Texts = Math.Round(time, 2) + "";
            txt_bugs.Texts = Math.Round(bugs, 2) + "";
            txt_difficulty.Texts = Math.Round(difficulty, 2) + "";
            txt_effort.Texts = Math.Round(effort, 2) + "";
        }

        public Form1()
        {
            InitializeComponent();
        }
        void calculate(double n1, double N1, double n2, double N2)
        {
            vocabulary = n1 + n2;
            length = N1 + N2;
            volume = (N1 + N2) * Math.Log(n1 + n2, 2);
            difficulty = (n1 / 2) * (N2 / n2);
            level = 1 / difficulty;
            estimated_length = n1 * Math.Log(n1, 2) + n2 * Math.Log(n2, 2);
            effort = difficulty * volume;
            bugs = Math.Pow(effort, (2 / 3)) / 3000;
            time = effort / 18;
        }
    }
}
