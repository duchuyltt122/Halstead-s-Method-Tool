﻿namespace HalsteadsMethodTool
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.rjButton1 = new RJCodeAdvance.RJControls.RJButton();
            this.txt_total_operands = new RJCodeAdvance.RJControls.RJTextBox();
            this.txt_distinct_operands = new RJCodeAdvance.RJControls.RJTextBox();
            this.txt_total_operators = new RJCodeAdvance.RJControls.RJTextBox();
            this.txt_distinct_operators = new RJCodeAdvance.RJControls.RJTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_bugs = new RJCodeAdvance.RJControls.RJTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_time = new RJCodeAdvance.RJControls.RJTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_effort = new RJCodeAdvance.RJControls.RJTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_level = new RJCodeAdvance.RJControls.RJTextBox();
            this.txt_vocabulary = new RJCodeAdvance.RJControls.RJTextBox();
            this.txt_difficulty = new RJCodeAdvance.RJControls.RJTextBox();
            this.txt_volume = new RJCodeAdvance.RJControls.RJTextBox();
            this.txt_estimated_length = new RJCodeAdvance.RJControls.RJTextBox();
            this.txt_length = new RJCodeAdvance.RJControls.RJTextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Violet;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(915, 61);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(199, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(380, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "Halstead\'s Method Tool";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MediumTurquoise;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.rjButton1);
            this.panel2.Controls.Add(this.txt_total_operands);
            this.panel2.Controls.Add(this.txt_distinct_operands);
            this.panel2.Controls.Add(this.txt_total_operators);
            this.panel2.Controls.Add(this.txt_distinct_operators);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 61);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(457, 734);
            this.panel2.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(92, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "Input";
            // 
            // rjButton1
            // 
            this.rjButton1.BackColor = System.Drawing.Color.LimeGreen;
            this.rjButton1.BackgroundColor = System.Drawing.Color.LimeGreen;
            this.rjButton1.BorderColor = System.Drawing.Color.PaleVioletRed;
            this.rjButton1.BorderRadius = 20;
            this.rjButton1.BorderSize = 0;
            this.rjButton1.FlatAppearance.BorderSize = 0;
            this.rjButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.rjButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rjButton1.ForeColor = System.Drawing.Color.White;
            this.rjButton1.Location = new System.Drawing.Point(117, 402);
            this.rjButton1.Name = "rjButton1";
            this.rjButton1.Size = new System.Drawing.Size(150, 40);
            this.rjButton1.TabIndex = 2;
            this.rjButton1.Text = "Submit";
            this.rjButton1.TextColor = System.Drawing.Color.White;
            this.rjButton1.UseVisualStyleBackColor = false;
            this.rjButton1.Click += new System.EventHandler(this.rjButton1_Click);
            // 
            // txt_total_operands
            // 
            this.txt_total_operands.BackColor = System.Drawing.SystemColors.Window;
            this.txt_total_operands.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_total_operands.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_total_operands.BorderRadius = 15;
            this.txt_total_operands.BorderSize = 2;
            this.txt_total_operands.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total_operands.ForeColor = System.Drawing.Color.Black;
            this.txt_total_operands.Location = new System.Drawing.Point(66, 329);
            this.txt_total_operands.Margin = new System.Windows.Forms.Padding(4);
            this.txt_total_operands.Multiline = false;
            this.txt_total_operands.Name = "txt_total_operands";
            this.txt_total_operands.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_total_operands.PasswordChar = false;
            this.txt_total_operands.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txt_total_operands.PlaceholderText = "";
            this.txt_total_operands.Size = new System.Drawing.Size(250, 35);
            this.txt_total_operands.TabIndex = 1;
            this.txt_total_operands.Texts = "";
            this.txt_total_operands.UnderlinedStyle = false;
            // 
            // txt_distinct_operands
            // 
            this.txt_distinct_operands.BackColor = System.Drawing.SystemColors.Window;
            this.txt_distinct_operands.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_distinct_operands.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_distinct_operands.BorderRadius = 15;
            this.txt_distinct_operands.BorderSize = 2;
            this.txt_distinct_operands.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_distinct_operands.ForeColor = System.Drawing.Color.Black;
            this.txt_distinct_operands.Location = new System.Drawing.Point(66, 259);
            this.txt_distinct_operands.Margin = new System.Windows.Forms.Padding(4);
            this.txt_distinct_operands.Multiline = false;
            this.txt_distinct_operands.Name = "txt_distinct_operands";
            this.txt_distinct_operands.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_distinct_operands.PasswordChar = false;
            this.txt_distinct_operands.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txt_distinct_operands.PlaceholderText = "";
            this.txt_distinct_operands.Size = new System.Drawing.Size(250, 35);
            this.txt_distinct_operands.TabIndex = 1;
            this.txt_distinct_operands.Texts = "";
            this.txt_distinct_operands.UnderlinedStyle = false;
            // 
            // txt_total_operators
            // 
            this.txt_total_operators.BackColor = System.Drawing.SystemColors.Window;
            this.txt_total_operators.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_total_operators.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_total_operators.BorderRadius = 15;
            this.txt_total_operators.BorderSize = 2;
            this.txt_total_operators.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_total_operators.ForeColor = System.Drawing.Color.Black;
            this.txt_total_operators.Location = new System.Drawing.Point(66, 188);
            this.txt_total_operators.Margin = new System.Windows.Forms.Padding(4);
            this.txt_total_operators.Multiline = false;
            this.txt_total_operators.Name = "txt_total_operators";
            this.txt_total_operators.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_total_operators.PasswordChar = false;
            this.txt_total_operators.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txt_total_operators.PlaceholderText = "";
            this.txt_total_operators.Size = new System.Drawing.Size(250, 35);
            this.txt_total_operators.TabIndex = 1;
            this.txt_total_operators.Texts = "";
            this.txt_total_operators.UnderlinedStyle = false;
            // 
            // txt_distinct_operators
            // 
            this.txt_distinct_operators.BackColor = System.Drawing.SystemColors.Window;
            this.txt_distinct_operators.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_distinct_operators.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_distinct_operators.BorderRadius = 15;
            this.txt_distinct_operators.BorderSize = 2;
            this.txt_distinct_operators.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_distinct_operators.ForeColor = System.Drawing.Color.Black;
            this.txt_distinct_operators.Location = new System.Drawing.Point(66, 117);
            this.txt_distinct_operators.Margin = new System.Windows.Forms.Padding(4);
            this.txt_distinct_operators.Multiline = false;
            this.txt_distinct_operators.Name = "txt_distinct_operators";
            this.txt_distinct_operators.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_distinct_operators.PasswordChar = false;
            this.txt_distinct_operators.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txt_distinct_operators.PlaceholderText = "";
            this.txt_distinct_operators.Size = new System.Drawing.Size(250, 35);
            this.txt_distinct_operators.TabIndex = 1;
            this.txt_distinct_operators.Texts = "";
            this.txt_distinct_operators.UnderlinedStyle = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(12, 303);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(362, 20);
            this.label16.TabIndex = 0;
            this.label16.Text = "Total number of occurrences of operands:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(12, 233);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(253, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "Number of distinct operands:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(12, 162);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(365, 20);
            this.label14.TabIndex = 0;
            this.label14.Text = "Total number of occurrences of operators:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(18, 332);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(49, 22);
            this.label21.TabIndex = 0;
            this.label21.Text = "(N2)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(24, 332);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(46, 22);
            this.label20.TabIndex = 0;
            this.label20.Text = "(n1)";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(18, 262);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 22);
            this.label19.TabIndex = 0;
            this.label19.Text = "(n2)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(18, 191);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(49, 22);
            this.label18.TabIndex = 0;
            this.label18.Text = "(N1)";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(18, 123);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(46, 22);
            this.label17.TabIndex = 0;
            this.label17.Text = "(n1)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(12, 91);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(256, 20);
            this.label13.TabIndex = 0;
            this.label13.Text = "Number of distinct operators:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Yellow;
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.txt_bugs);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.txt_time);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.txt_effort);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.txt_level);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.txt_vocabulary);
            this.panel3.Controls.Add(this.txt_difficulty);
            this.panel3.Controls.Add(this.txt_volume);
            this.panel3.Controls.Add(this.txt_estimated_length);
            this.panel3.Controls.Add(this.txt_length);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(457, 61);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(458, 734);
            this.panel3.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(76, 645);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(126, 20);
            this.label12.TabIndex = 0;
            this.label12.Text = "Program bugs";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(76, 577);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(162, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "Programming time";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(76, 509);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 20);
            this.label10.TabIndex = 0;
            this.label10.Text = "Program effort";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(76, 441);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(125, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Program level";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(76, 373);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(176, 20);
            this.label8.TabIndex = 0;
            this.label8.Text = "Program vocabulary";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(73, 303);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 20);
            this.label7.TabIndex = 0;
            this.label7.Text = "Program difficulty";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(73, 233);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Program volume";
            // 
            // txt_bugs
            // 
            this.txt_bugs.BackColor = System.Drawing.Color.White;
            this.txt_bugs.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_bugs.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_bugs.BorderRadius = 15;
            this.txt_bugs.BorderSize = 2;
            this.txt_bugs.Enabled = false;
            this.txt_bugs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_bugs.ForeColor = System.Drawing.Color.Black;
            this.txt_bugs.Location = new System.Drawing.Point(77, 674);
            this.txt_bugs.Margin = new System.Windows.Forms.Padding(4);
            this.txt_bugs.Multiline = false;
            this.txt_bugs.Name = "txt_bugs";
            this.txt_bugs.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_bugs.PasswordChar = false;
            this.txt_bugs.PlaceholderColor = System.Drawing.Color.White;
            this.txt_bugs.PlaceholderText = "";
            this.txt_bugs.Size = new System.Drawing.Size(250, 35);
            this.txt_bugs.TabIndex = 1;
            this.txt_bugs.Texts = "";
            this.txt_bugs.UnderlinedStyle = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(73, 162);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(225, 20);
            this.label5.TabIndex = 0;
            this.label5.Text = "Program estimated length";
            // 
            // txt_time
            // 
            this.txt_time.BackColor = System.Drawing.Color.White;
            this.txt_time.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_time.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_time.BorderRadius = 15;
            this.txt_time.BorderSize = 2;
            this.txt_time.Enabled = false;
            this.txt_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_time.ForeColor = System.Drawing.Color.Black;
            this.txt_time.Location = new System.Drawing.Point(77, 606);
            this.txt_time.Margin = new System.Windows.Forms.Padding(4);
            this.txt_time.Multiline = false;
            this.txt_time.Name = "txt_time";
            this.txt_time.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_time.PasswordChar = false;
            this.txt_time.PlaceholderColor = System.Drawing.Color.White;
            this.txt_time.PlaceholderText = "";
            this.txt_time.Size = new System.Drawing.Size(250, 35);
            this.txt_time.TabIndex = 1;
            this.txt_time.Texts = "";
            this.txt_time.UnderlinedStyle = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(70, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 20);
            this.label4.TabIndex = 0;
            this.label4.Text = "Program length";
            // 
            // txt_effort
            // 
            this.txt_effort.BackColor = System.Drawing.Color.White;
            this.txt_effort.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_effort.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_effort.BorderRadius = 15;
            this.txt_effort.BorderSize = 2;
            this.txt_effort.Enabled = false;
            this.txt_effort.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_effort.ForeColor = System.Drawing.Color.Black;
            this.txt_effort.Location = new System.Drawing.Point(77, 538);
            this.txt_effort.Margin = new System.Windows.Forms.Padding(4);
            this.txt_effort.Multiline = false;
            this.txt_effort.Name = "txt_effort";
            this.txt_effort.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_effort.PasswordChar = false;
            this.txt_effort.PlaceholderColor = System.Drawing.Color.White;
            this.txt_effort.PlaceholderText = "";
            this.txt_effort.Size = new System.Drawing.Size(250, 35);
            this.txt_effort.TabIndex = 1;
            this.txt_effort.Texts = "";
            this.txt_effort.UnderlinedStyle = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(97, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 32);
            this.label3.TabIndex = 0;
            this.label3.Text = "Output";
            // 
            // txt_level
            // 
            this.txt_level.BackColor = System.Drawing.Color.White;
            this.txt_level.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_level.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_level.BorderRadius = 15;
            this.txt_level.BorderSize = 2;
            this.txt_level.Enabled = false;
            this.txt_level.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_level.ForeColor = System.Drawing.Color.Black;
            this.txt_level.Location = new System.Drawing.Point(77, 470);
            this.txt_level.Margin = new System.Windows.Forms.Padding(4);
            this.txt_level.Multiline = false;
            this.txt_level.Name = "txt_level";
            this.txt_level.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_level.PasswordChar = false;
            this.txt_level.PlaceholderColor = System.Drawing.Color.White;
            this.txt_level.PlaceholderText = "";
            this.txt_level.Size = new System.Drawing.Size(250, 35);
            this.txt_level.TabIndex = 1;
            this.txt_level.Texts = "";
            this.txt_level.UnderlinedStyle = false;
            // 
            // txt_vocabulary
            // 
            this.txt_vocabulary.BackColor = System.Drawing.Color.White;
            this.txt_vocabulary.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_vocabulary.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_vocabulary.BorderRadius = 15;
            this.txt_vocabulary.BorderSize = 2;
            this.txt_vocabulary.Enabled = false;
            this.txt_vocabulary.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_vocabulary.ForeColor = System.Drawing.Color.Black;
            this.txt_vocabulary.Location = new System.Drawing.Point(77, 402);
            this.txt_vocabulary.Margin = new System.Windows.Forms.Padding(4);
            this.txt_vocabulary.Multiline = false;
            this.txt_vocabulary.Name = "txt_vocabulary";
            this.txt_vocabulary.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_vocabulary.PasswordChar = false;
            this.txt_vocabulary.PlaceholderColor = System.Drawing.Color.White;
            this.txt_vocabulary.PlaceholderText = "";
            this.txt_vocabulary.Size = new System.Drawing.Size(250, 35);
            this.txt_vocabulary.TabIndex = 1;
            this.txt_vocabulary.Texts = "";
            this.txt_vocabulary.UnderlinedStyle = false;
            // 
            // txt_difficulty
            // 
            this.txt_difficulty.BackColor = System.Drawing.Color.White;
            this.txt_difficulty.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_difficulty.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_difficulty.BorderRadius = 15;
            this.txt_difficulty.BorderSize = 2;
            this.txt_difficulty.Enabled = false;
            this.txt_difficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_difficulty.ForeColor = System.Drawing.Color.Black;
            this.txt_difficulty.Location = new System.Drawing.Point(74, 332);
            this.txt_difficulty.Margin = new System.Windows.Forms.Padding(4);
            this.txt_difficulty.Multiline = false;
            this.txt_difficulty.Name = "txt_difficulty";
            this.txt_difficulty.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_difficulty.PasswordChar = false;
            this.txt_difficulty.PlaceholderColor = System.Drawing.Color.White;
            this.txt_difficulty.PlaceholderText = "";
            this.txt_difficulty.Size = new System.Drawing.Size(250, 35);
            this.txt_difficulty.TabIndex = 1;
            this.txt_difficulty.Texts = "";
            this.txt_difficulty.UnderlinedStyle = false;
            // 
            // txt_volume
            // 
            this.txt_volume.BackColor = System.Drawing.Color.White;
            this.txt_volume.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_volume.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_volume.BorderRadius = 15;
            this.txt_volume.BorderSize = 2;
            this.txt_volume.Enabled = false;
            this.txt_volume.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_volume.ForeColor = System.Drawing.Color.Black;
            this.txt_volume.Location = new System.Drawing.Point(74, 262);
            this.txt_volume.Margin = new System.Windows.Forms.Padding(4);
            this.txt_volume.Multiline = false;
            this.txt_volume.Name = "txt_volume";
            this.txt_volume.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_volume.PasswordChar = false;
            this.txt_volume.PlaceholderColor = System.Drawing.Color.White;
            this.txt_volume.PlaceholderText = "";
            this.txt_volume.Size = new System.Drawing.Size(250, 35);
            this.txt_volume.TabIndex = 1;
            this.txt_volume.Texts = "";
            this.txt_volume.UnderlinedStyle = false;
            // 
            // txt_estimated_length
            // 
            this.txt_estimated_length.BackColor = System.Drawing.Color.White;
            this.txt_estimated_length.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_estimated_length.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_estimated_length.BorderRadius = 15;
            this.txt_estimated_length.BorderSize = 2;
            this.txt_estimated_length.Enabled = false;
            this.txt_estimated_length.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_estimated_length.ForeColor = System.Drawing.Color.Black;
            this.txt_estimated_length.Location = new System.Drawing.Point(74, 191);
            this.txt_estimated_length.Margin = new System.Windows.Forms.Padding(4);
            this.txt_estimated_length.Multiline = false;
            this.txt_estimated_length.Name = "txt_estimated_length";
            this.txt_estimated_length.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_estimated_length.PasswordChar = false;
            this.txt_estimated_length.PlaceholderColor = System.Drawing.Color.White;
            this.txt_estimated_length.PlaceholderText = "";
            this.txt_estimated_length.Size = new System.Drawing.Size(250, 35);
            this.txt_estimated_length.TabIndex = 1;
            this.txt_estimated_length.Texts = "";
            this.txt_estimated_length.UnderlinedStyle = false;
            // 
            // txt_length
            // 
            this.txt_length.BackColor = System.Drawing.Color.White;
            this.txt_length.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_length.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_length.BorderRadius = 15;
            this.txt_length.BorderSize = 2;
            this.txt_length.Enabled = false;
            this.txt_length.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_length.ForeColor = System.Drawing.Color.Black;
            this.txt_length.Location = new System.Drawing.Point(71, 120);
            this.txt_length.Margin = new System.Windows.Forms.Padding(4);
            this.txt_length.Multiline = false;
            this.txt_length.Name = "txt_length";
            this.txt_length.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txt_length.PasswordChar = false;
            this.txt_length.PlaceholderColor = System.Drawing.Color.White;
            this.txt_length.PlaceholderText = "";
            this.txt_length.Size = new System.Drawing.Size(250, 35);
            this.txt_length.TabIndex = 1;
            this.txt_length.Texts = "";
            this.txt_length.UnderlinedStyle = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::HalsteadsMethodTool.Properties.Resources.cal;
            this.pictureBox2.Location = new System.Drawing.Point(20, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(48, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::HalsteadsMethodTool.Properties.Resources.key;
            this.pictureBox1.Location = new System.Drawing.Point(22, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 795);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Halstead\'s Method Tool";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private RJCodeAdvance.RJControls.RJTextBox txt_distinct_operators;
        private RJCodeAdvance.RJControls.RJTextBox txt_length;
        private RJCodeAdvance.RJControls.RJButton rjButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private RJCodeAdvance.RJControls.RJTextBox txt_bugs;
        private System.Windows.Forms.Label label5;
        private RJCodeAdvance.RJControls.RJTextBox txt_time;
        private System.Windows.Forms.Label label4;
        private RJCodeAdvance.RJControls.RJTextBox txt_effort;
        private System.Windows.Forms.Label label3;
        private RJCodeAdvance.RJControls.RJTextBox txt_level;
        private RJCodeAdvance.RJControls.RJTextBox txt_vocabulary;
        private RJCodeAdvance.RJControls.RJTextBox txt_difficulty;
        private RJCodeAdvance.RJControls.RJTextBox txt_volume;
        private RJCodeAdvance.RJControls.RJTextBox txt_estimated_length;
        private RJCodeAdvance.RJControls.RJTextBox txt_total_operands;
        private RJCodeAdvance.RJControls.RJTextBox txt_distinct_operands;
        private RJCodeAdvance.RJControls.RJTextBox txt_total_operators;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label13;
    }
}

